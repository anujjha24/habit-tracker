Server side code created with Node.js, Express, Typescript and Mongoose/MongoDB.

In the project directory, you can run:

### `npm run start:dev`

Starts the server in development mode at http://localhost:3003.<br />

### `npm run start:test`

Starts the server in test mode. <br />

### `npm test`

Runs tests with Jest and Supertest
